package com.example.model;

import java.util.List;

public class EpubBook {
    private String title;
    private List<String> authors;
    private List<String> contents;

    // Конструкторы, геттеры и сеттеры
    public EpubBook(String title, List<String> authors, List<String> contents) {
        this.title = title;
        this.authors = authors;
        this.contents = contents;
    }

    public String getTitle() {
        return title;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public List<String> getContents() {
        return contents;
    }
}
    