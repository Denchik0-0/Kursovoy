package com.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class EpubReaderApp extends Application {
    @Override
    public void start(Stage primaryStage) {
        TextArea textArea = new TextArea();
        textArea.setEditable(false);

        VBox vbox = new VBox(textArea);
        Scene scene = new Scene(vbox, 600, 400);

        primaryStage.setTitle("EPUB Reader");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Загрузка содержимого EPUB
        loadEpubContent(textArea);
    }

    private void loadEpubContent(TextArea textArea) {
        // Здесь вы можете добавить код для загрузки и отображения содержимого EPUB
        textArea.setText("Здесь будет содержимое книги...");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
    