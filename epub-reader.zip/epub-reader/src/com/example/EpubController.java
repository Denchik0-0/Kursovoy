package com.example.controller;

import com.example.model.EpubBook;
import com.example.service.EpubService;

public class EpubController {
    private final EpubService epubService;

    public EpubController() {
        this.epubService = new EpubService();
    }

    public EpubBook loadEpub(String filePath) {
        return epubService.readEpub(filePath);
    }
}
    