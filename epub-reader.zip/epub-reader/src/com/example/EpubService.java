package com.example.service;

import com.example.model.EpubBook;
import nl.siegmann.epublib.epub.EpubReader;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

public class EpubService {
    public EpubBook readEpub(String filePath) {
        try (FileInputStream epubFile = new FileInputStream(filePath)) {
            EpubReader epubReader = new EpubReader();
            nl.siegmann.epublib.domain.Book book = epubReader.readEpub(epubFile);

            // Извлекаем данные из книги
            String title = book.getTitle();
            List<String> authors = book.getMetadata().getAuthors();
            List<String> contents = book.getContents().stream()
                    .map(resource -> resource.getHref())
                    .toList(); // Или другой способ извлечь текст

            return new EpubBook(title, authors, contents);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
